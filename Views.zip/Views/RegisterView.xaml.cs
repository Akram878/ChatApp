using System.Windows.Controls;

namespace ChatApp.Views
{
    public partial class RegisterView : UserControl
    {
        public RegisterView()
        {
            InitializeComponent();
        }
    }
}

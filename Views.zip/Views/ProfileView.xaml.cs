using System.Windows.Controls;

namespace ChatApp.Views
{
    public partial class ProfileView : UserControl
    {
        public ProfileView()
        {
            InitializeComponent();
        }
    }
}

using System.Windows.Controls;

namespace ChatApp.Views
{
    public partial class ChatView : UserControl
    {
        public ChatView()
        {
            InitializeComponent();
        }
    }
}
